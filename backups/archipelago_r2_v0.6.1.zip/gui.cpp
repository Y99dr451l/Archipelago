#include "gui.h"

auto app = Gtk::Application::create("org.gtkmm.example");
//static Gtk::Application app;

Gui::Gui() {
	setlabel();
	
	but_exit.signal_clicked().connect( sigc::mem_fun(*this,&Gui::cexit) );
	but_create.signal_clicked().connect( sigc::mem_fun(*this,&Gui::ccreate) );
	but_open.signal_clicked().connect( sigc::mem_fun(*this,&Gui::copen) );
	but_save.signal_clicked().connect( sigc::mem_fun(*this,&Gui::csave) );
	but_path.signal_clicked().connect( sigc::mem_fun(*this,&Gui::cpath) );
	but_zoomin.signal_clicked().connect( sigc::mem_fun(*this,&Gui::czoomin) );
	but_zoomout.signal_clicked().connect( sigc::mem_fun(*this,&Gui::czoomout) );
	but_zoomres.signal_clicked().connect( sigc::mem_fun(*this,&Gui::czoomres) );
	but_editlink.signal_clicked().connect( sigc::mem_fun(*this,&Gui::ceditlink) );
	
	buildgui();
}

Gui::~Gui(){}
Dessin::Dessin() {}
Dessin::~Dessin() {}

void init_gui() {
	auto app = Gtk::Application::create("org.gtkmm.example");
	//app.create("org.gtkmm.example");
	//while (1==1) {
		Gui gui;
		//Gui* guip(&gui);
		app->run(gui);
		//delete &gui;
	//}
}

bool Dessin::on_draw(const Cairo::RefPtr<Cairo::Context>& cr) {
	Gtk::Allocation allocation = get_allocation();
	const int width = allocation.get_width();
	const int height = allocation.get_height();
	demarrer_graphic(cr, width, height);
	Ville ville;
	ville.dessiner_ville();
	ville.calcul_enj();
	ville.afficher_enj_ci();
	return true;
}

void Gui::setlabel() {
	but_exit.set_label("Exit");
	but_create.set_label("New");
	but_open.set_label("Open");
	but_save.set_label("Save");
	but_path.set_label("Shortest path");
	but_zoomin.set_label("Zoom in (I)");
	but_zoomout.set_label("Zoom out (O)");
	but_zoomres.set_label("Reset zoom (R)");
	but_editlink.set_label("Edit link");
	rbhousing.set_label("Housing");
	rbtransport.set_label("Transport");
	rbproduction.set_label("Production");
}

void Gui::buildgui() {
	set_title("Archipelago");
	set_border_width(10);
	drawa.set_size_request(700,700);
	int bpad(2);
	
	box_general.set_homogeneous(1);
	box_general.set_orientation(Gtk::ORIENTATION_VERTICAL);	
	box_general.pack_start(but_exit,Gtk::PACK_EXPAND_WIDGET,bpad);
	box_general.pack_start(but_create,Gtk::PACK_EXPAND_WIDGET,bpad);
	box_general.pack_start(but_open,Gtk::PACK_EXPAND_WIDGET,bpad);
	box_general.pack_start(but_save,Gtk::PACK_EXPAND_WIDGET,bpad);

	fgeneral.set_label("General");
	fgeneral.set_shadow_type(Gtk::SHADOW_ETCHED_OUT);
	fgeneral.add(box_general);
	
	box_display.set_homogeneous(1);
	box_display.set_orientation(Gtk::ORIENTATION_VERTICAL);	
	box_display.pack_start(but_path,Gtk::PACK_EXPAND_WIDGET,bpad);
	box_display.pack_start(but_zoomin,Gtk::PACK_EXPAND_WIDGET,bpad);
	box_display.pack_start(but_zoomout,Gtk::PACK_EXPAND_WIDGET,bpad);
	box_display.pack_start(but_zoomres,Gtk::PACK_EXPAND_WIDGET,bpad);
	box_display.pack_start(lzoom,Gtk::PACK_EXPAND_WIDGET,0);
	
	fdisplay.set_label("Display");
	fdisplay.set_shadow_type(Gtk::SHADOW_ETCHED_OUT);
	fdisplay.add(box_display);
	
	rbtransport.join_group(rbhousing);
	rbproduction.join_group(rbhousing);
	
	box_editor.set_homogeneous(1);
	box_editor.set_orientation(Gtk::ORIENTATION_VERTICAL);	
	box_editor.pack_start(but_editlink,Gtk::PACK_EXPAND_WIDGET,bpad);
	box_editor.pack_start(rbhousing,Gtk::PACK_EXPAND_WIDGET,0);
	box_editor.pack_start(rbtransport,Gtk::PACK_EXPAND_WIDGET,0);
	box_editor.pack_start(rbproduction,Gtk::PACK_EXPAND_WIDGET,0);
	
	feditor.set_label("Editor");
	feditor.set_shadow_type(Gtk::SHADOW_ETCHED_OUT);
	feditor.add(box_editor);
	
	box_info.set_orientation(Gtk::ORIENTATION_VERTICAL);
	box_info.pack_start(lenj,Gtk::PACK_EXPAND_WIDGET,0);
	box_info.pack_start(lci,Gtk::PACK_EXPAND_WIDGET,0);
	box_info.pack_start(lmta,Gtk::PACK_EXPAND_WIDGET,0);
	
	finfo.set_label("Informations");
	finfo.set_shadow_type(Gtk::SHADOW_ETCHED_OUT);
	finfo.add(box_info);
	
	box_menu.set_orientation(Gtk::ORIENTATION_VERTICAL);
	box_menu.pack_start(fgeneral,Gtk::PACK_SHRINK,0);
	box_menu.pack_start(fdisplay,Gtk::PACK_SHRINK,0);
	box_menu.pack_start(feditor,Gtk::PACK_SHRINK,0);
	box_menu.pack_start(finfo,Gtk::PACK_SHRINK,0);
	
	fdrawa.set_label("Drawing Area");
	fdrawa.set_shadow_type(Gtk::SHADOW_ETCHED_OUT);
	fdrawa.add(drawa);
	
	box_main.set_orientation(Gtk::ORIENTATION_HORIZONTAL);
	box_main.pack_start(box_menu,Gtk::PACK_SHRINK,5);
	box_main.pack_start(fdrawa,Gtk::PACK_EXPAND_WIDGET,0);
	
	add(box_main);

	show_all_children();
}

void Gui::button_text(Glib::ustring data) {
	std::cout << data << " was pressed" << std::endl;
}

void Gui::cexit() {
	button_text(but_exit.get_label());
	exit(1);
}

void Gui::ccreate() {
	button_text(but_create.get_label());
	std::string s("/n");
	init(s);
	Ville ville;
	ville.nettoyer();
	//demarrer_graphic();
	//g_application_quit(&app);
	//app->quit();
}

void Gui::copen() {
	button_text(but_open.get_label());
	Gtk::FileChooserDialog dialog("Choose a file", Gtk::FILE_CHOOSER_ACTION_OPEN);
	//dialog.set_transient_for(gui);
	dialog.add_button("_Cancel", Gtk::RESPONSE_CANCEL);
	dialog.add_button("_Open", Gtk::RESPONSE_OK);
	auto filter_text = Gtk::FileFilter::create();
	filter_text->set_name("Text files");
	filter_text->add_mime_type("text/plain");
	dialog.add_filter(filter_text);
	int result = dialog.run();
	switch(result) {
		case(Gtk::RESPONSE_OK): {
			button_text("Open");
			std::string filename = dialog.get_filename();
			std::cout << "File selected: " <<  filename << std::endl;
			init(filename);
			break;
		}
		case(Gtk::RESPONSE_CANCEL): {
			button_text("Cancel");
			break;
		}
		default: {
			button_text("Unexpected button");
			break;
		}
	}
}

void Gui::csave() {
	button_text(but_save.get_label());
	Gtk::FileChooserDialog dialog("Save a file", Gtk::FILE_CHOOSER_ACTION_SAVE);
	dialog.add_button("_Cancel", Gtk::RESPONSE_CANCEL);
	dialog.add_button("_Save", Gtk::RESPONSE_OK);
	auto filter_text = Gtk::FileFilter::create();
	filter_text->set_name("Text files");
	filter_text->add_mime_type("text/plain");
	dialog.add_filter(filter_text);
	int result = dialog.run();
	switch(result) {
		case(Gtk::RESPONSE_OK): {
			button_text("Save");
			std::string filename = dialog.get_filename();
			std::cout << "File selected: " <<  filename << std::endl;
			//ecrire_ville(filename);
			break;
		}
		case(Gtk::RESPONSE_CANCEL): {
			button_text("Cancel");
			break;
		}
		default: {
			button_text("Unexpected button");
			break;
		}
	}
}

void Gui::cpath() {
	button_text(but_path.get_label());
}

void Gui::czoomin() {
	button_text(but_zoomin.get_label());
}

void Gui::czoomout() {
	button_text(but_zoomout.get_label());
}

void Gui::czoomres() {
	button_text(but_zoomres.get_label());
}

void Gui::ceditlink() {
	button_text(but_editlink.get_label());
}
