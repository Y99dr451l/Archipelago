#include "tools.h"

//ajouter une fonction de changement de couleur

double distance_points(S2d point1, S2d point2) {
	return (sqrt((point1.x - point2.x) * (point1.x - point2.x) +
			(point1.y - point2.y) * (point1.y - point2.y))); 
}

bool collision_cercles(Cercle c1, Cercle c2) {
	if (distance_points(c1.centre, c2.centre) <=
		(c1.rayon + c2.rayon)) return true; //dist_min
	else return false;
}

double distance_point_droite(S2d p, Droite d) {
	S2d vect_1_3 = { p.x - d.point.x,p.y - d.point.y };
	double d_scal = (vect_1_3.x * d.vect_dir.x + vect_1_3.y * d.vect_dir.y) /
					sqrt(d.vect_dir.x * d.vect_dir.x + d.vect_dir.y * d.vect_dir.y);
	double c_test = sqrt(vect_1_3.x * vect_1_3.x + vect_1_3.y * vect_1_3.y);
	double d_test = sqrt(c_test * c_test - d_scal * d_scal);
	return d_test;
}

double prod_scal(S2d vecteur_1, S2d vecteur_2) {
	return (vecteur_1.x * vecteur_2.x + vecteur_1.y * vecteur_2.y); 
}

bool collision_segment_cercle_entre(Cercle c, S2d p1, S2d p2) {
	S2d vecteur_1 = {p2.x - p1.x, p2.y - p1.y};
	S2d vecteur_p1_c = {c.centre.x - p1.x, c.centre.y - p1.y};
	if (prod_scal(vecteur_1, vecteur_p1_c) <= 0) return false;
	S2d vecteur_2 = {-vecteur_1.x, -vecteur_1.y};
	S2d vecteur_p2_c = {c.centre.x - p2.x, c.centre.y - p2.y};
	if (prod_scal(vecteur_2, vecteur_p2_c) <= 0) return false;
	Droite d = {p1 , vecteur_1};
	if (distance_point_droite(c.centre, d) <= c.rayon) return true; //dist_min
	return false;
}

void dessiner_logement(double& centre_x, double& centre_y,
					   double& rayon) {
	dessiner_cercle(centre_x, centre_y, rayon);
}

void dessiner_detail_transport(double& centre_x, double& centre_y,
							   double& rayon) {
	double projection(rayon*sqrt(2)/2.); //magic numberz?
	dessiner_trait(centre_x - rayon, centre_y,
				   centre_x + rayon, centre_y);
	dessiner_trait(centre_x, centre_y - rayon,
				   centre_x, centre_y + rayon);
	dessiner_trait(centre_x - projection, centre_y + projection,
				   centre_x + projection, centre_y - projection);
	dessiner_trait(centre_x - projection, centre_y - projection,
				   centre_x + projection, centre_y + projection);
}

void dessiner_detail_production(double& centre_x, double& centre_y,
							   double& rayon) {
	double decalage_x(3./8 * rayon), decalage_y(1./16 * rayon); //magic numberz?
	dessiner_trait(centre_x - decalage_x, centre_y + decalage_y,
				   centre_x + decalage_x, centre_y + decalage_y);
	dessiner_trait(centre_x - decalage_x, centre_y + decalage_y,
				   centre_x - decalage_x, centre_y - decalage_y);
	dessiner_trait(centre_x + decalage_x, centre_y - decalage_y,
				   centre_x + decalage_x, centre_y + decalage_y);
	dessiner_trait(centre_x + decalage_x, centre_y - decalage_y,
				   centre_x - decalage_x, centre_y - decalage_y);
}

void errormsg(std::string errorstr) {
	std::cout << errorstr << std::endl;
	errorwin(errorstr);
}
