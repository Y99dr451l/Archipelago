#include <iostream>
#include "ville.h"
#include "gui.h"

#include <iostream> //enlever

#define UN 1
#define DEUX 2

using namespace std;

int main(int argc, char* argv[]) {
	if (argc > DEUX) {
		cout << "Saisie incorrecte: execution sans argument "
				"ou avec l'adresse d'un seul fichier";
		exit(1);
	}
	if(argc == DEUX) {
		string s(argv[UN]);
		init(s);
	}
	init_gui();
	return 0;
}

