#include "noeud.h"

#define DEUX 2

Noeud::Noeud() {}

//
std::array<unsigned int, 3>  Noeud::somme_quartiers;

std::array<unsigned int, 3> Noeud::getSommequartier() {
	return somme_quartiers;
}

void Logement::incrementer_quartier() {
	somme_quartiers[0] += 1;	//not sure for ++somme_quartiers[i], test if works
}

void Transport::incrementer_quartier() {
	somme_quartiers[1] += 1;
}

void Production::incrementer_quartier() {
	somme_quartiers[2] += 1;
}

void Noeud::sauvegarder(std::ofstream& os) {
	os << getX() << " " << getY() << " " << getNbp() << std::endl;
}
//

std::array<unsigned int, 3>  Noeud::somme_nbp_quartiers;

Noeud::Noeud(size_t& uid_, double& x_, double& y_, unsigned int& nbp_,
			 std::vector<Noeud*>& noeuds): 
	uid(uid_),
	nbp(nbp_),
	nb_liens(0)
	{
		test_creation_noeud(uid_, x_, y_, nbp_, noeuds);
		S2d centre_noeud = { x_, y_ };
		c = { centre_noeud, sqrt(nbp_) }; //essayer = { S2d(x_, y_), sqrt... } puis mettre dans la liste d'init si pos
}

Noeud::~Noeud() {}

Logement::Logement(size_t& uid_, double& x_, double& y_, unsigned int& nbp_,
		  std::vector<Noeud*>& noeuds):
	Noeud::Noeud(uid_, x_, y_, nbp_, noeuds)
	{										//magic number?
	type = 0;
	incrementer_nbp_quartier(nbp_);
	
	incrementer_quartier();
	
}

void Logement::incrementer_nbp_quartier(unsigned int& nbp) {
	somme_nbp_quartiers[0]+= nbp;						//magic number?
}

void Logement::me_dessiner() {
	dessiner_logement(c.centre.x, c.centre.y, c.rayon); //ok
}

Transport::Transport(size_t& uid_, double& x_, double& y_, unsigned int& nbp_,
	      std::vector<Noeud*>& noeuds):	
	Noeud::Noeud(uid_, x_, y_, nbp_, noeuds)
	{									//magic numberz?
	type = 1;
	incrementer_nbp_quartier(nbp_);
	
	incrementer_quartier();
	
}

void Transport::incrementer_nbp_quartier(unsigned int& nbp) {
	somme_nbp_quartiers[1]+= nbp;						//magic number?
}

void Transport::me_dessiner() {
	dessiner_cercle(c.centre.x, c.centre.y, c.rayon); //voir si illégal d'utiliser des fonctions de graphic sans passer par tools.
	dessiner_detail_transport(c.centre.x, c.centre.y, c.rayon);
}

Production::Production(size_t& uid_, double& x_, double& y_, unsigned int& nbp_,
	      std::vector<Noeud*>& noeuds):
	Noeud::Noeud(uid_, x_, y_, nbp_, noeuds)
	{ 								//magic numberz?
	type = 2;
	incrementer_nbp_quartier(nbp_);
	
	incrementer_quartier();
	
}

void Production::incrementer_nbp_quartier(unsigned int& nbp) {
	somme_nbp_quartiers[2]+= nbp;					//magic number?
}

void Production::me_dessiner() {
	dessiner_cercle(c.centre.x, c.centre.y, c.rayon); //voir si illégal d'utiliser des fonctions de graphic sans passer par tools.
	dessiner_detail_production(c.centre.x, c.centre.y, c.rayon);
}

int Noeud::getType() {
	return type;
}

double Noeud::getRayon() {
	return c.rayon;
}

unsigned int Noeud::getNbp() {
	return nbp;
}

double Noeud::getX() {
	return c.centre.x;
}

double Noeud::getY() {
	return c.centre.y;
}

std::array<unsigned int, 3> Noeud::getNbpquartiers() {
	return somme_nbp_quartiers;
}

size_t Noeud::getUid() {
	return uid;
}

void Noeud::ajouter_lien() {
		++nb_liens;
	}
unsigned int Noeud::get_nbLiens() { 
	return nb_liens;
}

Cercle Noeud::getCercle() {
	return c;
}

void decodage_chaine_noeud(std::vector<Noeud*>& noeuds,
						   std::istringstream& iss, int& type) {
	Noeud* ptr_n(nullptr);
	size_t uid; //combiner size_t et unsigned int plutôt non?
	double x, y;
	unsigned int nbp;
	iss >> uid >> x >> y >> nbp;
	switch (type) {
		case 0:
			ptr_n = (new Logement(uid, x, y, nbp, noeuds));
			break;
		case 1:
			ptr_n = (new Transport(uid, x, y, nbp, noeuds));
			break;
		case 2:
			ptr_n = (new Production(uid, x, y, nbp, noeuds));
			break;
	}
	//Noeud noeud(uid, x, y, nbp, type, noeuds);
	noeuds.push_back(ptr_n);
}

void decodage_chaine_lien(std::vector<Noeud*>& noeuds, std::istringstream& iss,
						  std::vector<std::array<size_t, 2>>& liens) {
	size_t depart, arrivee;
	iss >> depart >> arrivee;
	test_creation_lien(depart, arrivee, liens, noeuds);
	std::array<size_t,DEUX> lien = {depart, arrivee}; //idem idée de la classe anonyme pour gagner une ligne
	liens.push_back(lien);
}

void test_creation_noeud(size_t& uid, double& x, double& y, unsigned int& nbp,
	std::vector<Noeud*>& noeuds) {
	if (uid == no_link) errormsg(error::reserved_uid());
	if (nbp < min_capacity) errormsg(error::too_little_capacity(nbp));
	if (nbp > max_capacity) errormsg(error::too_much_capacity(nbp));
	S2d centre_noeud;
	Cercle c;
	for (int i(0), taille(noeuds.size()); i < taille; ++i) {
		if ((*noeuds[i]).getUid() == uid) errormsg(error::identical_uid(uid));
		centre_noeud = { x, y };
		c = { centre_noeud, sqrt(nbp) };
		if (collision_cercles(c, (*noeuds[i]).getCercle()))
			errormsg(error::node_node_superposition(uid, (*noeuds[i]).getUid()));
	}
}

void test_creation_lien(size_t& depart, size_t& arrivee,
						std::vector<std::array<size_t, 2>>& liens,
						std::vector<Noeud*>& noeuds) {
	int compte(0), existe(0);
	size_t liens_depart(0), liens_arrivee(0);
	constexpr size_t sortie(2), increment(1);
	if (depart == arrivee) errormsg(error::self_link_node(depart));
	for (int i(0), taille(liens.size()); i < taille; ++i) {
		if ((liens[i].front() == depart and liens[i].back() == arrivee) or
			(liens[i].back() == depart and liens[i].front() == arrivee))
			errormsg(error::multiple_same_link(depart, arrivee));
	}
	for (int i(0), taille(noeuds.size()); i < taille; ++i) {
		if ((*noeuds[i]).getUid() == depart) {
			if ((*noeuds[i]).get_nbLiens() + increment > max_link)
				errormsg(error::max_link(depart));
			(*noeuds[i]).ajouter_lien();
			liens_depart = i;
			++compte;
			++existe;
			if (compte == sortie) break;
		}
		if ((*noeuds[i]).getUid() == arrivee) {
			if ((*noeuds[i]).get_nbLiens() + increment > max_link)
				errormsg(error::max_link(arrivee));
			(*noeuds[i]).ajouter_lien();
			liens_arrivee = i;
			++compte;
			if (compte == sortie) break;
		}
	}
	if (compte != sortie) {
		switch (existe) {
			case 0 : errormsg(error::link_vacuum(depart));
				break;
			case 1 : errormsg(error::link_vacuum(arrivee));
				break;
		}
	}
	S2d p1 = { (*noeuds[liens_depart]).getX(), (*noeuds[liens_depart]).getY() };
	S2d p2 = { (*noeuds[liens_arrivee]).getX(), (*noeuds[liens_arrivee]).getY() };
	for (int i(0), taille(noeuds.size()); i < taille; ++i) {
		if (collision_segment_cercle_entre((*noeuds[i]).getCercle(), p1, p2))
			errormsg(error::node_link_superposition((*noeuds[i]).getUid()));
	}
}
