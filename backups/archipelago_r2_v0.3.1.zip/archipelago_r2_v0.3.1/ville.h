#ifndef VILLE_H
#define VILLE_H

#include <string>
#include <vector>
#include <array>
#include <iostream>
#include <fstream>
#include <sstream>
#include "noeud.h"
#include "tools.h"
#include "error.h"

void init(std::string& nom_fichier);
void dessiner_ville();

static std::vector<Noeud*> noeuds;
static std::vector<std::array<size_t, 2>> liens;

class Ville {
public:
	void lecture(std::string& nom_fichier);
	void nettoyer();
	Ville();
	virtual ~Ville();
};
#endif
