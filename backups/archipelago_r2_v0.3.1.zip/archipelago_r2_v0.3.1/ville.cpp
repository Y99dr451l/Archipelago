#include "ville.h"

using namespace std;

#define DEUX 2

static bool getline_filtre(ifstream& fichier, string& ligne);

Ville::Ville() {}

void init(string& nom_fichier) {
	Ville ville;
	ville.lecture(nom_fichier);
}

void dessiner_ville() {
	for (size_t i(0), taille(noeuds.size()) ; i < taille ; ++i) {
		(*noeuds[i]).me_dessiner();
	}
}

void Ville::nettoyer() {
	for (size_t i(0), taille(noeuds.size()) ; i < taille ; ++i) {
		(*noeuds[i]).~Noeud();
		noeuds[i] = nullptr;
	}
	noeuds.clear();
}

Ville::~Ville() {}

static bool getline_filtre(ifstream& fichier, string& ligne) {
	if (!getline(fichier >> ws, ligne)) return 0;
	if (ligne.front() == '#') return getline_filtre(fichier, ligne);
	else return 1;
}

void Ville::lecture(string& nom_fichier) {
	int type(0), temp;
	string ligne;
	ifstream fichier(nom_fichier);
	while (getline_filtre(fichier, ligne)) {
		istringstream iss1(ligne);
		iss1 >> temp;
		for (int i(0) ; i < temp ; ++i) {
			getline_filtre(fichier, ligne);
			istringstream iss2(ligne);
			if (type <= DEUX) {
				decodage_chaine_noeud(noeuds, iss2, type);
			} else {
				decodage_chaine_lien(noeuds, iss2, liens);
			}
		}
		++type;
	}
	cout << error::success();
}
