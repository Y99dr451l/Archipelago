#ifndef NOEUD_H
#define NOEUD_H

#include <vector>
#include <array>
#include <iostream>
#include <sstream>
#include "tools.h"
#include "error.h"

class Noeud {
private:
	//Cercle c;
	size_t uid;
	unsigned int nbp;
	unsigned int nb_liens;
public:
	Noeud();
	Noeud(size_t& uid_, double& x_, double& y_, unsigned int& nbp_,
		  std::vector<Noeud*>& noeuds);
	virtual ~Noeud();
	double getRayon();
	unsigned int getNbp();
	double getX();
	double getY();
	Cercle getCercle();
	size_t getUid();
	unsigned int get_nbLiens();
	void ajouter_lien();
	virtual void me_dessiner() =0; //si on dessine le noeud, on a toutes les infos dessus, bonne idée de mettre public?
protected:
	Cercle c;
};

class Logement : public Noeud {
	public:
	Logement(size_t& uid_, double& x_, double& y_, unsigned int& nbp_,
		  std::vector<Noeud*>& noeuds);
	void me_dessiner();
};

class Transport : public Noeud {
	public:
	Transport(size_t& uid_, double& x_, double& y_, unsigned int& nbp_,
	      std::vector<Noeud*>& noeuds);
	void me_dessiner();
};

class Production : public Noeud {
	public:
	Production(size_t& uid_, double& x_, double& y_, unsigned int& nbp_,
	      std::vector<Noeud*>& noeuds);
	void me_dessiner();
};

void decodage_chaine_noeud(std::vector<Noeud*>& noeuds,
						   std::istringstream& iss, int& type);
void decodage_chaine_lien(std::vector<Noeud*>& noeuds, std::istringstream& iss,
						  std::vector<std::array<size_t, 2>>& liens);
void test_creation_noeud(size_t& uid, double& x, double& y,
			 unsigned int& nbp, std::vector<Noeud*>& noeuds);
void test_creation_lien(size_t& depart, size_t& arrivee,
						std::vector<std::array<size_t, 2>>& liens,
						std::vector<Noeud*>& noeuds);
#endif
