#ifndef GRAPHIC_H
#define GRAPHIC_H

#include <gtkmm.h>
#include <cmath>

void dessiner_cercle(double centre_x, double centre_y, double rayon); 
void dessiner_trait(double x0, double y0, double x1, double y1); //jsp, j'arrive pas à mettre les & sans générer une erreur
double changement_coordonnees_x(double x);
double changement_coordonnees_y(double y);

#endif
