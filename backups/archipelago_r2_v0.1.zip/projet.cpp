#include <iostream>
#include "ville.h"
//#include "gui.h"

using namespace std;

#define UN 1
#define DEUX 2

int main(int argc, char* argv[]) {
	while (argc != DEUX) {
		cout << "Saisie incorrecte, n'insérez que "
				"le nom l'exécutable suivi de celui du fichier d'entrée";
	}
	string s(argv[UN]);
	init(s);
	//gui_init(argc, argv);
	return 0;
}
