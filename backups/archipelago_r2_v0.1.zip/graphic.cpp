#include "graphic.h"

void dessiner_cercle(const Cairo::RefPtr<Cairo::Context>& cr,
					 double centre_x, double centre_y,
					 double rayon) {
	cr->set_line_width(10.0); //chercher quelle épaisseur choisir
	cr->set_source_rgb(0.8, 0.0, 0.0); //doit dépendre d'un type énum
	//cr->arc(7*unit_w, 1.5*unit_w, unit_w, -0.5*M_PI, 0.5*M_PI); centre x, y, rayon, debut, fin ! sens horaire !
	cr->arc(centre_x, centre_y, rayon, -M_PI, M_PI); //rappel, il y a peut être une méthode type show() à appeler
	/*
	cr->move_to(xc, 0);
	cr->line_to(0, yc);
	*/
}

void dessiner_trait(const Cairo::RefPtr<Cairo::Context>& cr,
					double x0, double y0, double x1, double y1) {
	cr->set_line_width(10.0); //chercher quelle épaisseur choisir
	cr->set_source_rgb(0.8, 0.0, 0.0); //doit dépendre d'un type énum
	cr->move_to(x0, y0);
	cr->line_to(x1, y1);  //rappel, il y a peut être une méthode type show() à appeler
}
