#ifndef VILLE_H
#define VILLE_H

#include <string>
#include <vector>
#include <array>
#include <iostream>
#include <fstream>
#include <sstream>
#include "noeud.h"
#include "tools.h"
#include "error.h"

void init(std::string& nom_fichier);

class Ville {
public:
	void lecture(std::string& nom_fichier);
	void nettoyer();
	Ville();
	virtual ~Ville();
private:
	std::vector<Noeud*> noeuds;
	std::vector<std::array<size_t, 2>> liens;
};
#endif
