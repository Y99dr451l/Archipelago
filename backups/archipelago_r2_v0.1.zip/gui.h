#ifndef GUI_H
#define GUI_H

//#include "ville.h"
//#include "tools.h"

init_gui(int& argc, char*& argv[]);

#endif
