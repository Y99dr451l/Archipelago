#ifndef GRAPHIC_COLOR_H
#define GRAPHIC_COLOR_H

enum Couleur {Noir, Blanc, Rouge, Vert};

#endif