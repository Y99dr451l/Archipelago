#include "gui.h"

Gui::Gui()
/*:but_exit("Exit"), but_create("New"), but_open("Open"), but_save("Save"),
			but_path("Shortest paths"), but_zoomin("Zoom in (I)"),
			but_zoomout("Zoom out (O)"), but_zoomres("Reset zoom (R)"),
			but_editlink("Edit link"), lzoom("Zoom: "), lenj("ENJ: "), lci("CI: "), lmta("MTA: "),
			rbhousing("Housing"), rbtransport("Transport"), rbproduction("Production")
			*/
{
	but_exit.set_label("Exit");
	buildgui();
	/*
	but_exit.signal_clicked().connect(sigc::bind<Glib::ustring>(sigc::mem_fun(*this, &Gui::on_button_clicked), "Exit"));
	but_create.signal_clicked().connect(sigc::bind<Glib::ustring>(sigc::mem_fun(*this, &Gui::on_button_clicked), "New"));
	but_open.signal_clicked().connect(sigc::bind<Glib::ustring>(sigc::mem_fun(*this, &Gui::on_button_clicked), "Exit"));
	but_save.signal_clicked().connect(sigc::bind<Glib::ustring>(sigc::mem_fun(*this, &Gui::on_button_clicked), "Exit"));
	but_path.signal_clicked().connect(sigc::bind<Glib::ustring>(sigc::mem_fun(*this, &Gui::on_button_clicked), "Exit"));
	but_zoomin.signal_clicked().connect(sigc::bind<Glib::ustring>(sigc::mem_fun(*this, &Gui::on_button_clicked), "Exit"));
	but_zoomout.signal_clicked().connect(sigc::bind<Glib::ustring>(sigc::mem_fun(*this, &Gui::on_button_clicked), "Exit"));
	but_zoomres.signal_clicked().connect(sigc::bind<Glib::ustring>(sigc::mem_fun(*this, &Gui::on_button_clicked), "Exit"));
	*/
	//but_exit.signal_clicked().connect(exit(1));
}

Gui::~Gui(){}

MButton::MButton() {}
MButton::~MButton() {}

Dessin::Dessin() {}
Dessin::~Dessin() {}

int init_gui() {
	auto app = Gtk::Application::create("org.gtkmm.example");
	Gui gui;
	return app->run(gui);
}

bool Dessin::on_draw(const Cairo::RefPtr<Cairo::Context>& cr)
{
	demarrer_graphic(cr);
	dessiner_ville();
	
	return true;
}

void Gui::buildgui() {
	set_title("Archipelago");
	set_border_width(10);
	drawa.set_size_request(500,500); //magic numberz?
	int bpad(1);
	box_general.set_homogeneous(1);
	box_general.set_orientation(Gtk::ORIENTATION_VERTICAL);	
	box_general.pack_start(but_exit,Gtk::PACK_EXPAND_WIDGET,bpad);
	box_general.pack_start(but_create,Gtk::PACK_EXPAND_WIDGET,bpad);
	box_general.pack_start(but_open,Gtk::PACK_EXPAND_WIDGET,bpad);
	box_general.pack_start(but_save,Gtk::PACK_EXPAND_WIDGET,bpad);

	fgeneral.set_label("General");
	fgeneral.set_shadow_type(Gtk::SHADOW_ETCHED_OUT);
	fgeneral.add(box_general);
	
	box_display.set_homogeneous(1);
	box_display.set_orientation(Gtk::ORIENTATION_VERTICAL);	
	box_display.pack_start(but_path,Gtk::PACK_EXPAND_WIDGET,bpad);
	box_display.pack_start(but_zoomin,Gtk::PACK_EXPAND_WIDGET,bpad);
	box_display.pack_start(but_zoomout,Gtk::PACK_EXPAND_WIDGET,bpad);
	box_display.pack_start(but_zoomres,Gtk::PACK_EXPAND_WIDGET,bpad);
	box_display.pack_start(lzoom,Gtk::PACK_EXPAND_WIDGET,0);
	
	fdisplay.set_label("Display");
	fdisplay.set_shadow_type(Gtk::SHADOW_ETCHED_OUT);
	fdisplay.add(box_display);
	
	rbtransport.join_group(rbhousing);
	rbproduction.join_group(rbhousing);
	
	box_editor.set_homogeneous(1);
	box_editor.set_orientation(Gtk::ORIENTATION_VERTICAL);	
	box_editor.pack_start(but_editlink,Gtk::PACK_EXPAND_WIDGET,bpad);
	box_editor.pack_start(rbhousing,Gtk::PACK_EXPAND_WIDGET,0);
	box_editor.pack_start(rbtransport,Gtk::PACK_EXPAND_WIDGET,0);
	box_editor.pack_start(rbproduction,Gtk::PACK_EXPAND_WIDGET,0);
	
	feditor.set_label("Editor");
	feditor.set_shadow_type(Gtk::SHADOW_ETCHED_OUT);
	feditor.add(box_editor);
	
	box_info.set_orientation(Gtk::ORIENTATION_VERTICAL);
	box_info.pack_start(lenj,Gtk::PACK_EXPAND_WIDGET,0);
	box_info.pack_start(lci,Gtk::PACK_EXPAND_WIDGET,0);
	box_info.pack_start(lmta,Gtk::PACK_EXPAND_WIDGET,0);
	
	finfo.set_label("Informations");
	finfo.set_shadow_type(Gtk::SHADOW_ETCHED_OUT);
	finfo.add(box_info);
	
	box_menu.set_orientation(Gtk::ORIENTATION_VERTICAL);
	box_menu.pack_start(fgeneral,Gtk::PACK_EXPAND_WIDGET,0);
	box_menu.pack_start(fdisplay,Gtk::PACK_EXPAND_WIDGET,0);
	box_menu.pack_start(feditor,Gtk::PACK_EXPAND_WIDGET,0);
	box_menu.pack_start(finfo,Gtk::PACK_EXPAND_WIDGET,0);
	
	box_main.set_orientation(Gtk::ORIENTATION_HORIZONTAL);
	box_main.pack_start(box_menu,Gtk::PACK_SHRINK,0);
	box_main.pack_start(drawa,Gtk::PACK_SHRINK,0);
	
	add(box_main);

	show_all_children();
}

void MButton::button_text(Glib::ustring data) {
  std::cout << data << std::endl;
}
