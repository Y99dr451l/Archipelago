#ifndef VILLE_H
#define VILLE_H

#include <string>
#include <vector>
#include <array>
#include <iostream>
#include <fstream>
#include <sstream>
#include "noeud.h"
#include "tools.h"
#include "error.h"



void init(std::string& nom_fichier);
void ecrire_ville(std::string& nom_fichier);

double calcul_mta(std::vector<Noeud*>& noeuds, std::vector<std::array<size_t,2>>& liens);

class Ville {
public:
	
	static void v_sauvegarder(std::string nom_fichier);
	static void trier_noeuds();
	
	void calcul_enj();
	void calcul_ci(size_t indice_x, size_t indice_y);
	void dessiner_ville();
	static void nettoyer();
	void incrementer_ci(double ajout);
	void setEnj(double nouv_valeur);
	void afficher_enj_ci();
	static void lecture(std::string& nom_fichier);
	Ville();
	virtual ~Ville();
private:

	static std::vector<Noeud**> n_ordre;

	static double ci, enj;
	static std::vector<Noeud*> noeuds;
	static std::vector<std::array<size_t, 2>> liens;
};
#endif
