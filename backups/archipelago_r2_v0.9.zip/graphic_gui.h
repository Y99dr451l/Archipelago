#ifndef GRAPHIC_GUI_H
#define GRAPHIC_GUI_H

#include "graphic.h"

void demarrer_graphic(const Cairo::RefPtr<Cairo::Context>& cr,
					  double w, double h);
#endif
