#include "ville.h"
#include <iostream> //enlever

using namespace std;

#define DEUX 2

static bool getline_filtre(ifstream& fichier, string& ligne);

std::vector<Noeud*> Ville::noeuds;
std::vector<std::array<size_t, 2>> Ville::liens;
std::vector<Noeud**> Ville::n_ordre;
double Ville::ci, Ville::enj;
//Ville* ptr_v = (new Ville());

Ville::Ville() {}
Ville::~Ville() {}

void init(string& nom_fichier) {
	Ville::nettoyer();
	Ville::lecture(nom_fichier);
}

double Ville::getEnj() {
	return enj;
}

double Ville::getCi() {
	return ci;
}

void Ville::v_sauvegarder(std::string nom_fichier) {
	ofstream os(nom_fichier);
	trier_noeuds();
	array<unsigned int, 3> nb_quart(Noeud::getSommequartier());
	int k(0);
	for (size_t i(0), k(0), taille(noeuds.size()+1) ; i < taille ; ++k) {
		if ( k < 3 ) {
			os << nb_quart[k] << endl;
			for (size_t j(0), taille(nb_quart[k]); j < taille ; ++i, ++j) {
				(**(n_ordre[i])).sauvegarder(os); //pas noeuds
				//os << i << endl;
			}
		} else {
			os << Noeud::getTotalliens() << std::endl;			//sous forme de test en ce moment, pourrait générer seg fault ou bug si essaie de générer fichier vide
			for (size_t j(0), taille(liens.size()); j < taille ; ++j) {
				os << liens[j].front() << " " << liens[j].back() << endl;
			}
			++i;
		}
	}
}

void Ville::trier_noeuds() { //parcoure 3 fois le vecteur noeuds;
	for (size_t i(0), taille(3) ; i < 3 ; ++i) {
		for (size_t j(0), taille(noeuds.size()) ; j < taille ; ++j) {
			if ((*noeuds[j]).getType() == i ) {
				Noeud** ptr_ptr_n(&noeuds[j]);
				n_ordre.push_back(ptr_ptr_n);
			}
		}
	}
}

void Ville::dessiner_ville() {
	size_t indice_x, indice_y;
	int sortie(0);
	for (size_t i(0), taille(liens.size()) ; i < taille ; ++i) {
		for (size_t j(0), taille(noeuds.size()) ; j < taille ; ++j) {
			if ((*noeuds[j]).getUid() == liens[i][0]) { //test .front()
				indice_x = j;
				++sortie;
				if (sortie == DEUX) break;
			}
			if ((*noeuds[j]).getUid() == liens[i][1]) { //test .back()
				indice_y = j;
				++sortie;
				if (sortie == DEUX) break;
			}
		}
		dessiner_trait((*noeuds[indice_x]).getX(), (*noeuds[indice_x]).getY(), //passer par tools plutôt?
					   (*noeuds[indice_y]).getX(), (*noeuds[indice_y]).getY());
		calcul_ci(indice_x, indice_y);
	}
	for (size_t i(0), taille(noeuds.size()) ; i < taille ; ++i) {
		(*noeuds[i]).me_dessiner();
	}
}

void Ville::calcul_ci(size_t indice_x, size_t indice_y) {
	S2d point1, point2;
	double distance_liens, vitesse_co, capacite_co;
	point1.x = (*noeuds[indice_x]).getX();
	point1.y = (*noeuds[indice_x]).getY();
	point2.x = (*noeuds[indice_y]).getX();
	point2.y = (*noeuds[indice_y]).getY();
	distance_liens = distance_points(point1, point2);
	if (((*noeuds[indice_x]).getType() == 1) and //voir avec opérateur intérogation : ?
		((*noeuds[indice_y]).getType() == 1)) { 	//magic numberz?
		vitesse_co = fast_speed;
	} else {
		vitesse_co = default_speed;
	}
	if ((*noeuds[indice_x]).getNbp() <= (*noeuds[indice_y]).getNbp()) { //voir avec opérateur intérogation : ?
		capacite_co = (*noeuds[indice_x]).getNbp();
	} else {
		capacite_co = (*noeuds[indice_y]).getNbp();
	}
	ci = 0;
	incrementer_ci(distance_liens * vitesse_co * capacite_co);
}

void Ville::afficher_enj_ci() {
	std::cout << enj  << " " << ci << std::endl;
}

void Ville::incrementer_ci(double ajout) {
	ci += ajout;
}

void Ville::calcul_enj() {
	std::array<unsigned int, 3> nbp_q = Noeud::getNbpquartiers();
	double temp0(nbp_q[0]), temp1(nbp_q[1]), temp2(nbp_q[2]), temp;
	if (temp0+temp1+temp2 == 0) {
		temp = 0;
	} else {
		temp = ((temp0 - (temp1 + temp2))/(temp0 + temp1 + temp2));
	}
	setEnj(temp);
}

void Ville::setEnj(double nouv_valeur) {
	enj = nouv_valeur;
}

void Ville::nettoyer() {
	Noeud::nettoyer_noeud();
	for (size_t i(0), taille(noeuds.size()) ; i < taille ; ++i) {
		(*noeuds[i]).~Noeud();
		noeuds[i] = nullptr;
	}
	noeuds.clear();
	liens.clear();
	n_ordre.clear();
	ci = 0;
	enj = 0;
}

static bool getline_filtre(ifstream& fichier, string& ligne) {
	if (!getline(fichier >> ws, ligne)) return 0;
	if (ligne.front() == '#') return getline_filtre(fichier, ligne);
	else return 1;
}

void Ville::lecture(string& nom_fichier) {
	int type(0), temp;
	string ligne;
	ifstream fichier(nom_fichier);
	while (getline_filtre(fichier, ligne)) {
		istringstream iss1(ligne);
		iss1 >> temp;
		for (int i(0) ; i < temp ; ++i) {
			getline_filtre(fichier, ligne);
			istringstream iss2(ligne);
			if (type <= DEUX) {
				decodage_chaine_noeud(noeuds, iss2, type);
			} else {
				decodage_chaine_lien(noeuds, iss2, liens);
			}
		}
		++type;
	}
	cout << error::success();
}

double calcul_mta(vector<Noeud*>& noeuds, vector<array<size_t,2>>& liens) {
	
}

//yolo starts here :
