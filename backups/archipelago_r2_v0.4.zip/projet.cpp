#include <iostream>
#include "ville.h"
#include "gui.h"

#define UN 1
#define DEUX 2

using namespace std;

int main(int argc, char* argv[]) {
	if (argc != DEUX) {
		cout << "Saisie incorrecte, n'insérez que "
				"le nom l'exécutable suivi de celui du fichier d'entrée";
		exit(1);
	}
	string s(argv[UN]);
	init(s);
	init_gui();
	return 0;
}
