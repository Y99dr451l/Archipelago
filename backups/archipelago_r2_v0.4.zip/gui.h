#ifndef GUI_H
#define GUI_H

#include <iostream>
#include <gtkmm/box.h>
#include <gtkmm/buttonbox.h>
#include <gtkmm/button.h>
#include <gtkmm/window.h>
#include <gtkmm/frame.h>
#include <gtkmm/drawingarea.h>
#include <gtkmm/label.h>
#include <gtkmm/radiobutton.h>
#include <gtkmm/filechooserdialog.h>
#include <fstream>
#include "ville.h"
#include "graphic_gui.h"

int init_gui();

class Dessin : public Gtk::DrawingArea {
public:
	Dessin();
	virtual ~Dessin();
protected:
	bool on_draw(const Cairo::RefPtr<Cairo::Context>& cr) override;
};

class Gui : public Gtk::Window {
public:
	Gui();
	virtual ~Gui();
protected:
	void setlabel();
	void button_text(Glib::ustring data);
	void buildgui();
	
	void cexit();
	void ccreate();
	void copen();
	void csave();
	void cpath();
	void czoomin();
	void czoomout();
	void czoomres();
	void ceditlink();
	
	Gtk::Frame fgeneral, fdisplay, feditor, finfo, fdrawa;
	Gtk::Box box_main, box_menu, box_general, box_display, box_editor, box_info;
	Gtk::Button but_exit, but_create, but_open, but_save, but_path, but_zoomin,
	but_zoomout, but_zoomres, but_editlink;
	Dessin drawa;
	Gtk::Label lzoom, lenj, lci, lmta;
	Gtk::RadioButton rbhousing, rbtransport, rbproduction;
};

#endif
