#include "graphic_gui.h"

static const Cairo::RefPtr<Cairo::Context>* ptcr(nullptr); //peut être bouger dans .h (lequel?)
static double width, height, lw;// x_min, y_min; //peut être bouger dans .h (lequel?)
static int r, g, b; //peut être bouger dans .h (lequel?)

void demarrer_graphic(const Cairo::RefPtr<Cairo::Context>& cr,
					  double w, double h) {
	ptcr = &cr;
	width = w;
	height = h;
	lw = 3.0; //à modifier
	r = 255;
	g = 0;
	b = 0;
	//x_min = width/2;
	//y_min = height/2;
	//ev bouger dans une autre fonction pour ensuite modifier
	(*ptcr)->set_line_width(lw); //chercher quelle épaisseur choisir
	(*ptcr)->set_source_rgb(r, g, b); //doit dépendre d'un type énum
	//
}

void dessiner_cercle(double centre_x, double centre_y, double rayon) {
	(*ptcr)->set_line_width(rayon);
	(*ptcr)->set_source_rgb(255, 255, 255);		//magic number?		
	(*ptcr)->arc(changement_coordonnees_x(centre_x),
				 changement_coordonnees_y(centre_y),
				 rayon/2., -M_PI, M_PI);					//magic number?
	(*ptcr)->stroke();
	(*ptcr)->set_line_width(lw); 
	(*ptcr)->set_source_rgb(r, g, b);			//
	(*ptcr)->arc(changement_coordonnees_x(centre_x),
				 changement_coordonnees_y(centre_y),
				 rayon, -M_PI, M_PI); //rappel, il y a peut être une méthode type show() à appeler
	(*ptcr)->stroke();
}

void dessiner_trait(double x0, double y0, double x1, double y1) {
	(*ptcr)->move_to(changement_coordonnees_x(x0),
					 changement_coordonnees_y(y0));
	(*ptcr)->line_to(changement_coordonnees_x(x1),
					 changement_coordonnees_y(y1));  //rappel, il y a peut être une méthode type show() à appeler
	(*ptcr)->stroke();
	
}

double changement_coordonnees_x(double x) { //ev revoir ces formules
	return width/2 + x;
}

double changement_coordonnees_y(double y) { //ev revoir ces formules
	return height/2 - y;
}
