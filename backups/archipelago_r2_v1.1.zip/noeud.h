#ifndef NOEUD_H
#define NOEUD_H

#include <vector>
#include <array>
#include <iostream>
#include <sstream>
#include <fstream>
#include "tools.h"
#include "error.h"

class Noeud {
private:
	size_t uid;
	unsigned int nbp;
	unsigned int nb_liens;
	
public:
	Noeud();
	Noeud(size_t& uid_, double& x_, double& y_, unsigned int& nbp_,
		  std::vector<Noeud*>& noeuds);
	virtual ~Noeud();
	
	static void nettoyer_noeud();
	static std::array<unsigned int, 3> getSommequartier();
	void sauvegarder(std::ofstream& os);
	virtual void incrementer_quartier() =0;
	void nouveau_voisin(Noeud* noeud);
	
	double getRayon();
	unsigned int getNbp();
	double getX();
	double getY();
	Cercle getCercle();
	size_t getUid();
	unsigned int get_nbLiens();
	double getAccess();
	int getType();
	static unsigned int getTotalliens();
	static std::array<unsigned int, 3> getNbpquartiers();
	bool getIn();
	std::vector<Noeud*> getVoisins();
	
	void setParent(unsigned int n);
	void setIn(bool n_in);
	void setAccess(double n_access);
	
	void ajouter_lien();
	virtual void me_dessiner() =0;
	virtual void incrementer_nbp_quartier(unsigned int& nbp) =0;
	
protected:
	int type;
	Cercle c;
	static unsigned int total_liens;
	std::vector<Noeud*> voisins;
	bool in;
	double access;
	unsigned int parent;
	static std::array<unsigned int, 3>  somme_quartiers;
	static std::array<unsigned int, 3>  somme_nbp_quartiers;
};

class Logement : public Noeud {
	public:
	Logement(size_t& uid_, double& x_, double& y_, unsigned int& nbp_,
		  std::vector<Noeud*>& noeuds);
	void me_dessiner();
	void incrementer_quartier();
	void incrementer_nbp_quartier(unsigned int& nbp);
};

class Transport : public Noeud {
	public:
	Transport(size_t& uid_, double& x_, double& y_, unsigned int& nbp_,
	      std::vector<Noeud*>& noeuds);
	void me_dessiner();
	void incrementer_quartier();
	void incrementer_nbp_quartier(unsigned int& nbp);
};

class Production : public Noeud {
	public:
	Production(size_t& uid_, double& x_, double& y_, unsigned int& nbp_,
	      std::vector<Noeud*>& noeuds);
	void me_dessiner();
	void incrementer_quartier();
	void incrementer_nbp_quartier(unsigned int& nbp);
};

void decodage_chaine_noeud(std::vector<Noeud*>& noeuds,
						   std::istringstream& iss, int& type);
void decodage_chaine_lien(std::vector<Noeud*>& noeuds, std::istringstream& iss,
						  std::vector<std::array<size_t, 2>>& liens);
void test_creation_noeud(size_t& uid, double& x, double& y,
			 unsigned int& nbp, std::vector<Noeud*>& noeuds);
void test_creation_lien(size_t& depart, size_t& arrivee,
						std::vector<std::array<size_t, 2>>& liens,
						std::vector<Noeud*>& noeuds);
#endif
