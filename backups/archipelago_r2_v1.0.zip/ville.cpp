#include "ville.h"
#include <iostream> //enlever

using namespace std;

#define DEUX 2

static bool getline_filtre(ifstream& fichier, string& ligne);

std::vector<Noeud*> Ville::noeuds;
std::vector<std::array<size_t, 2>> Ville::liens;
std::vector<Noeud**> Ville::n_ordre;
double Ville::ci, Ville::enj, Ville::mta;
//Ville* ptr_v = (new Ville());

Ville::Ville() {}
Ville::~Ville() {}

void init(string& nom_fichier) {
	Ville::nettoyer();
	Ville::lecture(nom_fichier);
}

double Ville::getEnj() {
	return enj;
}

double Ville::getCi() {
	return ci;
}

double Ville::getMta() {
	return mta;
}

void Ville::v_sauvegarder(std::string nom_fichier) {
	ofstream os(nom_fichier);
	trier_noeuds();
	array<unsigned int, 3> nb_quart(Noeud::getSommequartier());
	int k(0);
	for (size_t i(0), k(0), taille(noeuds.size()+1) ; i < taille ; ++k) {
		if ( k < 3 ) {
			os << nb_quart[k] << endl;
			for (size_t j(0), taille(nb_quart[k]); j < taille ; ++i, ++j) {
				(**(n_ordre[i])).sauvegarder(os); //pas noeuds
				//os << i << endl;
			}
		} else {
			os << Noeud::getTotalliens() << std::endl;			//sous forme de test en ce moment, pourrait générer seg fault ou bug si essaie de générer fichier vide
			for (size_t j(0), taille(liens.size()); j < taille ; ++j) {
				os << liens[j].front() << " " << liens[j].back() << endl;
			}
			++i;
		}
	}
}

void Ville::trier_noeuds() { //parcoure 3 fois le vecteur noeuds;
	for (size_t i(0), taille(3) ; i < 3 ; ++i) {
		for (size_t j(0), taille(noeuds.size()) ; j < taille ; ++j) {
			if ((*noeuds[j]).getType() == i ) {
				Noeud** ptr_ptr_n(&noeuds[j]);
				n_ordre.push_back(ptr_ptr_n);
			}
		}
	}
}

void Ville::dessiner_ville() {
	size_t indice_x, indice_y;
	int sortie(0);
	ci = 0;
	for (size_t i(0), taille(liens.size()) ; i < taille ; ++i) {
		for (size_t j(0), taille(noeuds.size()) ; j < taille ; ++j) {
			if ((*noeuds[j]).getUid() == liens[i][0]) { //test .front()
				indice_x = j;
				++sortie;
				if (sortie == DEUX) break;
			}
			if ((*noeuds[j]).getUid() == liens[i][1]) { //test .back()
				indice_y = j;
				++sortie;
				if (sortie == DEUX) break;
			}
		}
		dessiner_trait((*noeuds[indice_x]).getX(), (*noeuds[indice_x]).getY(), //passer par tools plutôt?
					   (*noeuds[indice_y]).getX(), (*noeuds[indice_y]).getY());
		calcul_ci(indice_x, indice_y);
	}
	for (size_t i(0), taille(noeuds.size()) ; i < taille ; ++i) {
		(*noeuds[i]).me_dessiner();
	}
}

void Ville::calcul_ci(size_t indice_x, size_t indice_y) {
	S2d point1, point2;
	double distance_liens, vitesse_co, capacite_co;
	point1.x = (*noeuds[indice_x]).getX();
	point1.y = (*noeuds[indice_x]).getY();
	point2.x = (*noeuds[indice_y]).getX();
	point2.y = (*noeuds[indice_y]).getY();
	distance_liens = distance_points(point1, point2);
	if (((*noeuds[indice_x]).getType() == 1) and //voir avec opérateur intérogation : ?
		((*noeuds[indice_y]).getType() == 1)) { 	//magic numberz?
		vitesse_co = fast_speed;
	} else {
		vitesse_co = default_speed;
	}
	if ((*noeuds[indice_x]).getNbp() <= (*noeuds[indice_y]).getNbp()) { //voir avec opérateur intérogation : ?
		capacite_co = (*noeuds[indice_x]).getNbp();
	} else {
		capacite_co = (*noeuds[indice_y]).getNbp();
	}
	incrementer_ci(distance_liens * capacite_co * vitesse_co);
}

void Ville::afficher_enj_ci_mta() {
	std::cout << enj  << " " << ci << " " << mta << std::endl;
}

void Ville::incrementer_ci(double ajout) {
	ci += ajout;
}

void Ville::calcul_enj() {
	std::array<unsigned int, 3> nbp_q = Noeud::getNbpquartiers();
	double temp0(nbp_q[0]), temp1(nbp_q[1]), temp2(nbp_q[2]), temp;
	if (temp0+temp1+temp2 == 0) {
		temp = 0;
	} else {
		temp = ((temp0 - (temp1 + temp2))/(temp0 + temp1 + temp2));
	}
	setEnj(temp);
}

void Ville::setEnj(double nouv_valeur) {
	enj = nouv_valeur;
}

void Ville::nettoyer() {
	Noeud::nettoyer_noeud();
	for (size_t i(0), taille(noeuds.size()) ; i < taille ; ++i) {
		(*noeuds[i]).~Noeud();
		noeuds[i] = nullptr;
	}
	noeuds.clear();
	liens.clear();
	n_ordre.clear();
	ci = 0;
	enj = 0;
}

static bool getline_filtre(ifstream& fichier, string& ligne) {
	if (!getline(fichier >> ws, ligne)) return 0;
	if (ligne.front() == '#') return getline_filtre(fichier, ligne);
	else return 1;
}

void Ville::lecture(string& nom_fichier) {
	int type(0), temp;
	string ligne;
	ifstream fichier(nom_fichier);
	while (getline_filtre(fichier, ligne)) {
		istringstream iss1(ligne);
		iss1 >> temp;
		for (int i(0) ; i < temp ; ++i) {
			getline_filtre(fichier, ligne);
			istringstream iss2(ligne);
			if (type <= DEUX) {
				decodage_chaine_noeud(noeuds, iss2, type);
			} else {
				decodage_chaine_lien(noeuds, iss2, liens);
			}
		}
		++type;
	}
	cout << error::success();
}

void Ville::calcul_mta() {
	double total(0);
	double nb_log(0);
	size_t dij1, dij2;
	for (size_t i(0), taille(noeuds.size()) ; i < taille ; ++i) {
		if ((*noeuds[i]).getType() == 0) {
			++nb_log;
			//cout << "noeud n°: " << i << " taille nbp: " << (*noeuds[i]).getNbp() << endl;
			dij1 = dijkstra(noeuds, i, 1);			//valeurs de access modifiées à chaque appel de dijkstra(...)!!!
			if (dij1 == no_link) {
				cout << "exeption infinite_time" << endl;
				mta = infinite_time;
				break;
			}
			total += (*noeuds[dij1]).getAccess();
			dij2 = dijkstra(noeuds, i, 2);
			if (dij2 == no_link) {
				cout << "exeption infinite_time" << endl;
				mta = infinite_time;
				break;
			}
			total += (*noeuds[dij2]).getAccess();
		}
	}
	if (nb_log == 0) {
		cout << "rien du tout " << 0 << endl;
		mta = 0;
	} else if (mta < infinite_time) {
		mta = (total/nb_log);
	}
}

//double dijkstra(vector<Noeud*>& tn, unsigned int ind_dep, int type)
//yolo starts here :
//the Dijkstra (in module ville)

size_t Ville::dijkstra(vector<Noeud*>& tn, size_t ind_dep, int type) {
	vector<size_t> ta;
	for (size_t i(0), taille(tn.size()) ; i < taille ; ++i) {
		ta.push_back(i);
		//cout << ta[i] << endl;
		(*tn[i]).setIn(true);
		(*tn[i]).setAccess(infinite_time);
		(*tn[i]).setParent(no_link);
	}
	swap(ta, 0, ind_dep);		//place l'indice de départ en premier élément de ta (osef du nouveau rang de l'autre)
	(*tn[ta.front()]).setAccess(0);
	size_t n(0);
	double alt(0);
	for (size_t avancement(0), max(tn.size()); avancement < max ; ++avancement) {
		if (min_access(tn, ta) == (-1)) {		//gère une exeption;
			return no_link;
		}
		n = ta[min_access(tn, ta)];
		if ((*tn[n]).getType() == type) {
			return n;
		}
		(*tn[n]).setIn(false);
		if ((*tn[n]).getType() != 2) {
		std::vector<Noeud*> voisins_tnn((*tn[n]).getVoisins());			//traiter cas d'un noeud sans voisin.
			for (size_t lv(0), taille(((*tn[n]).getVoisins()).size()) ; lv < taille ; ++lv) {
				if ((*voisins_tnn[lv]).getIn() == true) {
					alt = (*tn[n]).getAccess() + calculer_access(tn, voisins_tnn, lv, n);
					if ((*voisins_tnn[lv]).getAccess() > alt) {
						(*voisins_tnn[lv]).setAccess(alt);
						(*voisins_tnn[lv]).setParent(n);
						tri(tn, voisins_tnn, ta, lv);
					}
				}
			}
		}
	}
	return no_link; //tester si marche avec size_t
}

double Ville::min_access(vector<Noeud*>& tn, vector<size_t>& ta) {
	for (size_t i(0), taille(ta.size()) ; i < taille ; ++i) {
		if ((*tn[ta[i]]).getIn() == true) {
			return i;
		}
	}
	return (-1);
}

double Ville::calculer_access(vector<Noeud*>& tn, std::vector<Noeud*>& voisins_tnn, size_t& lv, size_t& n) {
	S2d point1, point2;
	point1.x = (*tn[n]).getX();
	point1.y = (*tn[n]).getY();
	point2.x = (*voisins_tnn[lv]).getX();
	point2.y = (*voisins_tnn[lv]).getY();
	if ((*tn[n]).getType() == 1 and (*voisins_tnn[lv]).getType() == 1) { //ok
		return distance_points(point1, point2)/fast_speed; //no rage
	}
	return distance_points(point1, point2)/default_speed;
}

void Ville::tri(vector<Noeud*>& tn, vector<Noeud*>& voisins, vector<size_t>& ta, size_t& lv) {
	size_t uid_v((*voisins[lv]).getUid()), indice, compteur(0);
	for (size_t i(0), taille(ta.size()) ; i < taille ; ++i) {	//supposé trouver l'indice dans ta associé à lv dans voisins du noeud n
		if ((*tn[ta[i]]).getUid() == uid_v) {
			indice = i;
			break;
		}
	}
	for (size_t i(0), taille(ta.size()) ; i < taille ; ++i) {
		if ((*tn[ta[i]]).getAccess() > (*tn[ta[indice]]).getAccess()) {
			for (size_t j(i) ; j < indice ; ++j) {
				swap(ta, j, indice);
			}
		break;
		}
	}
}

void Ville::swap(vector<size_t>& ta, size_t j, size_t indice) {
	size_t temp(ta[indice]);
	ta[indice] = ta[j];
	ta[j] = temp;
}

void Ville::afficher_ta(vector<size_t>& ta) {
	for (size_t i(0), taille(ta.size()) ; i < taille ; ++i) {
		cout << i << " " << ta[i] << endl;
	}
}
