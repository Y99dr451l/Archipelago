#ifndef GRAPHIC_H
#define GRAPHIC_H

#include <iostream>
#include <cmath>

#include "graphic_color.h"
#include "constantes.h"

#define EPAISSEUR 4

void dessiner_cercle(double centre_x, double centre_y,
					 double rayon, double epaisseur = EPAISSEUR);
void dessiner_trait(double x0, double y0, double x1,
					double y1, double epaisseur = EPAISSEUR);
double modeletodrawa_r(double rayon);
double modeletodrawa_x(double x);
double modeletodrawa_y(double y);
double drawatomodele_x(double dx);
double drawatomodele_y(double dy);
void rafraichir();
void modifier_couleur(int r, int g, int b);
void errorwin(std::string& errormsg);
#endif