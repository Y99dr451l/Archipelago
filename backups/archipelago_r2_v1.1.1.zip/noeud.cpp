#include "noeud.h"

unsigned int Noeud::total_liens;
std::array<unsigned int, 3>  Noeud::somme_quartiers;
std::array<unsigned int, 3>  Noeud::somme_nbp_quartiers;

namespace {
	bool errnoeud;
}

Noeud::Noeud(size_t& uid_, double& x_, double& y_, unsigned int& nbp_,
			 std::vector<Noeud*>& noeuds): uid(uid_), nbp(nbp_), nb_liens(0) {
		test_creation_noeud(uid_, x_, y_, nbp_, noeuds);
		S2d centre_noeud = { x_, y_ };
		c = { centre_noeud, sqrt(nbp_) };
}

Noeud::~Noeud() {}

std::array<unsigned int, 3> Noeud::getSommequartier() {
	return somme_quartiers;
}

void Noeud::nettoyer_noeud() {
	somme_quartiers.fill(0);
	somme_nbp_quartiers.fill(0);
	total_liens = 0;
}

void Logement::incrementer_quartier() {
	somme_quartiers[0] += 1;
}

void Transport::incrementer_quartier() {
	somme_quartiers[1] += 1;
}

void Production::incrementer_quartier() {
	somme_quartiers[2] += 1;
}

void Noeud::sauvegarder(std::ofstream& os) {
	os << getUid() << " " << getX() << " " << getY() << " " << getNbp() << std::endl;
}

Logement::Logement(size_t& uid_, double& x_, double& y_, unsigned int& nbp_,
		  std::vector<Noeud*>& noeuds):
	Noeud::Noeud(uid_, x_, y_, nbp_, noeuds) {
	type = 0;
	incrementer_nbp_quartier(nbp_);
	
	incrementer_quartier();
	
}

void Logement::incrementer_nbp_quartier(unsigned int& nbp) {
	somme_nbp_quartiers[0]+= nbp;
}

void Logement::me_dessiner() {
	dessiner_logement(c.centre.x, c.centre.y, c.rayon); //ok
}

Transport::Transport(size_t& uid_, double& x_, double& y_, unsigned int& nbp_,
	      std::vector<Noeud*>& noeuds):	
	Noeud::Noeud(uid_, x_, y_, nbp_, noeuds) {									
	type = 1;
	incrementer_nbp_quartier(nbp_);
	
	incrementer_quartier();
	
}

void Transport::incrementer_nbp_quartier(unsigned int& nbp) {
	somme_nbp_quartiers[1]+= nbp;
}

void Transport::me_dessiner() {
	 //voir si illégal d'utiliser des fonctions de graphic sans passer par tools.
	dessiner_detail_transport(c.centre.x, c.centre.y, c.rayon);
}

Production::Production(size_t& uid_, double& x_, double& y_, unsigned int& nbp_,
	      std::vector<Noeud*>& noeuds):
	Noeud::Noeud(uid_, x_, y_, nbp_, noeuds) { 								
	type = 2;
	incrementer_nbp_quartier(nbp_);
	
	incrementer_quartier();
	
}

void Production::incrementer_nbp_quartier(unsigned int& nbp) {
	somme_nbp_quartiers[2]+= nbp;
}

void Production::me_dessiner() {
	dessiner_cercle(c.centre.x, c.centre.y, c.rayon); //voir si illégal d'utiliser des fonctions de graphic sans passer par tools.
	dessiner_detail_production(c.centre.x, c.centre.y, c.rayon);
}

int Noeud::getType() {
	return type;
}

double Noeud::getRayon() {
	return c.rayon;
}

unsigned int Noeud::getNbp() {
	return nbp;
}

double Noeud::getX() {
	return c.centre.x;
}

double Noeud::getY() {
	return c.centre.y;
}

std::array<unsigned int, 3> Noeud::getNbpquartiers() {
	return somme_nbp_quartiers;
}

unsigned int Noeud::getTotalliens() {
	return total_liens;
}

size_t Noeud::getUid() {
	return uid;
}

void Noeud::ajouter_lien() {
		++nb_liens;
	}
unsigned int Noeud::get_nbLiens() { 
	return nb_liens;
}

Cercle Noeud::getCercle() {
	return c;
}

double Noeud::getAccess() {
	return access;
}

void Noeud::setAccess(double n_access) {
	access = n_access;
}

void Noeud::setParent(unsigned int n) {
	parent = n;
}

std::vector<Noeud*> Noeud::getVoisins() {
	return voisins;
}

void Noeud::setIn(bool n_in) {
	in = n_in;
}

bool Noeud::getIn() {
	return in;
}

bool decodage_chaine_noeud(std::vector<Noeud*>& noeuds,
						   std::istringstream& iss, int& type) {
	Noeud* ptr_n(nullptr);
	size_t uid;
	double x, y;
	unsigned int nbp;
	iss >> uid >> x >> y >> nbp;
	switch (type) {
		case 0:
			ptr_n = (new Logement(uid, x, y, nbp, noeuds));
			break;
		case 1:
			ptr_n = (new Transport(uid, x, y, nbp, noeuds));
			break;
		case 2:
			ptr_n = (new Production(uid, x, y, nbp, noeuds));
			break;
	}
	if (errnoeud) return true;
	noeuds.push_back(ptr_n);
	return false;
}

bool decodage_chaine_lien(std::vector<Noeud*>& noeuds, std::istringstream& iss,
						  std::vector<std::array<size_t, 2>>& liens) {
	size_t depart, arrivee;
	iss >> depart >> arrivee;
	if (test_creation_lien(depart, arrivee, liens, noeuds)) return true;
	std::array<size_t, 2> lien = {depart, arrivee};
	liens.push_back(lien);
	(*noeuds[0]).incrementer_total_liens();
	return false;
}

bool test_creation_noeud(size_t& uid, double& x, double& y, unsigned int& nbp,
	std::vector<Noeud*>& noeuds) {
	errnoeud = false;
	if (uid == no_link) {
		errormsg(error::reserved_uid());
		errnoeud = true;
		return true;
	}
	if (nbp < min_capacity) {
		errormsg(error::too_little_capacity(nbp));
		errnoeud = true;
		return true;
	}
	if (nbp > max_capacity) {
		errormsg(error::too_much_capacity(nbp));
		errnoeud = true;
		return true;
	}
	S2d centre_noeud;
	Cercle c;
	for (int i(0), taille(noeuds.size()); i < taille; ++i) {
		if ((*noeuds[i]).getUid() == uid) {
			errormsg(error::identical_uid(uid));
			errnoeud = true;
			return true;
		}
		centre_noeud = { x, y };
		c = { centre_noeud, sqrt(nbp) };
		if (collision_cercles(c, (*noeuds[i]).getCercle())) {
			errormsg(error::node_node_superposition(uid, (*noeuds[i]).getUid()));
			errnoeud = true;
			return true;
		}
	}
	return false;
}

bool test_creation_lien(size_t& depart, size_t& arrivee,
						std::vector<std::array<size_t, 2>>& liens,
						std::vector<Noeud*>& noeuds) {
	int compte(0), existe(0);
	size_t liens_depart(0), liens_arrivee(0);
	constexpr size_t sortie(2), increment(1);
	if (depart == arrivee) {
		errormsg(error::self_link_node(depart));
		return true;
	}
	for (int i(0), taille(liens.size()); i < taille; ++i) {
		if ((liens[i].front() == depart and liens[i].back() == arrivee) or
			(liens[i].back() == depart and liens[i].front() == arrivee)) {
			errormsg(error::multiple_same_link(depart, arrivee));
			return true;
		}
	}
	for (int i(0), taille(noeuds.size()); i < taille; ++i) {
		if ((*noeuds[i]).getUid() == depart) {
			if (((*noeuds[i]).getType() == 0) and 
			   ((*noeuds[i]).get_nbLiens() + increment > max_link)) {
				errormsg(error::max_link(depart));
				return true;
			}
			(*noeuds[i]).ajouter_lien();
			liens_depart = i;
			++compte;
			++existe;
			if (compte == sortie) break;
		}
		if ((*noeuds[i]).getUid() == arrivee) {
			if (((*noeuds[i]).getType() == 0) and 
			   ((*noeuds[i]).get_nbLiens() + increment > max_link)) {
				errormsg(error::max_link(arrivee));
				return true;
			}
			(*noeuds[i]).ajouter_lien();
			liens_arrivee = i;
			++compte;
			if (compte == sortie) break;
		}
	}
	if (compte != sortie) {
		switch (existe) {
			case 0 : errormsg(error::link_vacuum(depart));
				return true;
				break;
			case 1 : errormsg(error::link_vacuum(arrivee));
				return true;
				break;
		}
	}
	S2d p1 = { (*noeuds[liens_depart]).getX(), (*noeuds[liens_depart]).getY() };
	S2d p2 = { (*noeuds[liens_arrivee]).getX(), (*noeuds[liens_arrivee]).getY() };
	for (int i(0), taille(noeuds.size()); i < taille; ++i) {
		if (collision_segment_cercle_entre((*noeuds[i]).getCercle(), p1, p2)) {
			errormsg(error::node_link_superposition((*noeuds[i]).getUid()));
			return true;
		}
	}
	(*noeuds[liens_depart]).nouveau_voisin(noeuds[liens_arrivee]);
	(*noeuds[liens_arrivee]).nouveau_voisin(noeuds[liens_depart]);
	return false;
}

void Noeud::nouveau_voisin(Noeud* noeud) {
	voisins.push_back(noeud);
}

void Noeud::incrementer_total_liens() {
	++total_liens;
}
