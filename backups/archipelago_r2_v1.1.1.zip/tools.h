#ifndef TOOLS_H
#define TOOLS_H

#include <cmath>
#include <string>
#include <iostream>
#include "graphic.h"
#include "graphic_gui.h"
#include "constantes.h"

struct S2d {
	double x;
	double y;
};
struct Cercle {
	S2d centre;
	double rayon;
};
struct Droite {
	S2d point;
	S2d vect_dir;
};
double distance_points(S2d point1, S2d point2);
double distance_point_droite(S2d p, Droite d);
bool collision_cercles(Cercle c1, Cercle c2);
double prod_scal(S2d vecteur_1, S2d vecteur_2);
bool collision_segment_cercle_entre(Cercle c, S2d p1, S2d p2);
void dessiner_detail_transport(double& centre_x, double& centre_y, double& rayon);
void dessiner_detail_production(double& centre_x, double& centre_y, double& rayon);
void dessiner_logement(double& centre_x, double& centre_y, double& rayon);
void dessiner_blanc();	   
void errormsg(std::string errorstr);
#endif
