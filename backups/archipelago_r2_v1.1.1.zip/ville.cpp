#include "ville.h"
#include <iostream> //enlever

using namespace std;

static bool getline_filtre(ifstream& fichier, string& ligne);

Ville::Ville() {}
Ville::~Ville() {}

std::vector<Noeud*> Ville::noeuds;
std::vector<std::array<size_t, 2>> Ville::liens;
std::vector<Noeud**> Ville::n_ordre;
double Ville::ci, Ville::enj, Ville::mta;

void init(string& nom_fichier) {
	Ville::nettoyer();
	Ville::lecture(nom_fichier);
}

void Ville::nettoyer() {
	Noeud::nettoyer_noeud();
	for (size_t i(0), taille(noeuds.size()) ; i < taille ; ++i) {
		(*noeuds[i]).~Noeud();
		noeuds[i] = nullptr;
	}
	noeuds.clear();
	liens.clear();
	n_ordre.clear();
	ci = 0;
	enj = 0;
}

int Ville::lecture(string& nom_fichier) {
	int type(0), temp;
	string ligne;
	ifstream fichier(nom_fichier);
	while (getline_filtre(fichier, ligne)) {
		istringstream iss1(ligne);
		iss1 >> temp;
		for (int i(0) ; i < temp ; ++i) {
			getline_filtre(fichier, ligne);
			istringstream iss2(ligne);
			if (type <= 2) {
				if (decodage_chaine_noeud(noeuds, iss2, type)) {
					nettoyer();
					return 1;
				}
			} else {
				if (decodage_chaine_lien(noeuds, iss2, liens)) {
					nettoyer();
					return 1;
				}
			}
		}
		++type;
	}
	cout << error::success();
	return 0;
}

static bool getline_filtre(ifstream& fichier, string& ligne) {
	if (!getline(fichier >> ws, ligne)) return 0;
	if (ligne.front() == '#') return getline_filtre(fichier, ligne);
	else return 1;
}

void Ville::v_sauvegarder(std::string nom_fichier) {
	ofstream os(nom_fichier);
	trier_noeuds();
	array<unsigned int, 3> nb_quart(Noeud::getSommequartier());
	int k(0);
	for (size_t i(0), k(0), taille(noeuds.size()+1) ; i < taille ; ++k) {
		if ( k < 3 ) {
			os << nb_quart[k] << endl;
			for (size_t j(0), taille(nb_quart[k]); j < taille ; ++i, ++j) {
				(**(n_ordre[i])).sauvegarder(os);
			}
		} else {
			os << Noeud::getTotalliens() << std::endl;
			for (size_t j(0), taille(liens.size()); j < taille ; ++j) {
				os << liens[j].front() << " " << liens[j].back() << endl;
			}
			++i;
		}
	}
}

void Ville::trier_noeuds() {
	for (size_t i(0), taille(3) ; i < 3 ; ++i) {
		for (size_t j(0), taille(noeuds.size()) ; j < taille ; ++j) {
			if ((*noeuds[j]).getType() == i ) {
				Noeud** ptr_ptr_n(&noeuds[j]);
				n_ordre.push_back(ptr_ptr_n);
			}
		}
	}
}

void Ville::dessiner_ville() {
	dessiner_blanc();
	size_t indice_x, indice_y;
	int sortie(0);
	ci = 0;
	for (size_t i(0), taille(liens.size()) ; i < taille ; ++i) {
		for (size_t j(0), taille(noeuds.size()) ; j < taille ; ++j) {
			if ((*noeuds[j]).getUid() == liens[i].front()) { 
				indice_x = j;
				++sortie;
				if (sortie == 2) break;
			}
			if ((*noeuds[j]).getUid() == liens[i].back()) {
				indice_y = j;
				++sortie;
				if (sortie == 2) break;
			}
		}
		dessiner_trait((*noeuds[indice_x]).getX(), (*noeuds[indice_x]).getY(), //passer par tools plutôt?
					   (*noeuds[indice_y]).getX(), (*noeuds[indice_y]).getY());
		calcul_ci(indice_x, indice_y);
	}
	for (size_t i(0), taille(noeuds.size()) ; i < taille ; ++i) {
		(*noeuds[i]).me_dessiner();
	}
}

double Ville::getEnj() {
	return enj;
}

double Ville::getCi() {
	return ci;
}

double Ville::getMta() {
	return mta;
}

void Ville::calcul_enj() {
	std::array<unsigned int, 3> nbp_q = Noeud::getNbpquartiers();
	double temp0(nbp_q[0]), temp1(nbp_q[1]), temp2(nbp_q[2]), temp;
	if (temp0+temp1+temp2 == 0) temp = 0;
	else temp = ((temp0 - (temp1 + temp2))/(temp0 + temp1 + temp2));
	enj = temp;
}

void Ville::calcul_ci(size_t indice_x, size_t indice_y) {
	S2d point1, point2;
	double distance_liens, vitesse_co, capacite_co;
	point1.x = (*noeuds[indice_x]).getX();
	point1.y = (*noeuds[indice_x]).getY();
	point2.x = (*noeuds[indice_y]).getX();
	point2.y = (*noeuds[indice_y]).getY();
	distance_liens = distance_points(point1, point2);
	if (((*noeuds[indice_x]).getType() == 1) and ((*noeuds[indice_y]).getType() == 1))
		vitesse_co = fast_speed;
	else vitesse_co = default_speed;
	if ((*noeuds[indice_x]).getNbp() <= (*noeuds[indice_y]).getNbp())
		capacite_co = (*noeuds[indice_x]).getNbp();
	else capacite_co = (*noeuds[indice_y]).getNbp();
	incrementer_ci(distance_liens * capacite_co * vitesse_co);
}

void Ville::incrementer_ci(double ajout) {
	ci += ajout;
}

void Ville::calcul_mta() {
	double total(0);
	double nb_log(0);
	for (size_t i(0), taille(noeuds.size()) ; i < taille ; ++i) {
		if ((*noeuds[i]).getType() == 0) {
			++nb_log;
			for (int j(1); j < 3 ; j++) {
				size_t dij(dijkstra(noeuds, i, 1));
				if (dij == no_link) {
					mta = infinite_time;
					break;
				}
				total += (*noeuds[dij]).getAccess();
			}
		}
	}
	if (nb_log == 0) mta = 0;
	else if (mta < infinite_time) mta = (total/nb_log);
}

size_t Ville::dijkstra(vector<Noeud*>& tn, size_t ind_dep, int type) {
	vector<size_t> ta;
	for (size_t i(0), taille(tn.size()) ; i < taille ; ++i) {
		ta.push_back(i);
		(*tn[i]).setIn(true);
		(*tn[i]).setAccess(infinite_time);
		(*tn[i]).setParent(no_link);
	}
	swap(ta, 0, ind_dep);
	(*tn[ta.front()]).setAccess(0);
	size_t n(0);
	double alt(0);
	for (size_t avancement(0), max(tn.size()); avancement < max ; ++avancement) {
		int mina(min_access(tn, ta));
		if (mina == -1) return no_link;
		n = ta[mina];
		if ((*tn[n]).getType() == type) return n;
		(*tn[n]).setIn(false);
		if ((*tn[n]).getType() != 2) {
		std::vector<Noeud*> voisins_tnn((*tn[n]).getVoisins());
			for (size_t lv(0), taille(((*tn[n]).getVoisins()).size()) ; lv < taille ; ++lv) {
				if ((*voisins_tnn[lv]).getIn() == true) {
					alt = (*tn[n]).getAccess() + calculer_access(tn, voisins_tnn, lv, n);
					if ((*voisins_tnn[lv]).getAccess() > alt) {
						(*voisins_tnn[lv]).setAccess(alt);
						(*voisins_tnn[lv]).setParent(n);
						tri(tn, voisins_tnn, ta, lv);
					}
				}
			}
		}
	}
	return no_link;
}

double Ville::min_access(vector<Noeud*>& tn, vector<size_t>& ta) {
	for (size_t i(0), taille(ta.size()) ; i < taille ; ++i) {
		if ((*tn[ta[i]]).getIn() == true) return i;
	}
	return -1;
}

double Ville::calculer_access(vector<Noeud*>& tn, std::vector<Noeud*>& voisins_tnn, size_t& lv, size_t& n) {
	S2d point1, point2;
	point1.x = (*tn[n]).getX();
	point1.y = (*tn[n]).getY();
	point2.x = (*voisins_tnn[lv]).getX();
	point2.y = (*voisins_tnn[lv]).getY();
	if ((*tn[n]).getType() == 1 and (*voisins_tnn[lv]).getType() == 1)
		return distance_points(point1, point2)/fast_speed;
	return distance_points(point1, point2)/default_speed;
}

void Ville::tri(vector<Noeud*>& tn, vector<Noeud*>& voisins, vector<size_t>& ta, size_t& lv) {
	size_t uid_v((*voisins[lv]).getUid()), indice, compteur(0);
	for (size_t i(0), taille(ta.size()) ; i < taille ; ++i) {
		if ((*tn[ta[i]]).getUid() == uid_v) {
			indice = i;
			break;
		}
	}
	for (size_t i(0), taille(ta.size()) ; i < taille ; ++i) {
		if ((*tn[ta[i]]).getAccess() > (*tn[ta[indice]]).getAccess()) {
			for (size_t j(i) ; j < indice ; ++j) {
				swap(ta, j, indice);
			}
		break;
		}
	}
}

void Ville::swap(vector<size_t>& ta, size_t j, size_t indice) {
	size_t temp(ta[indice]);
	ta[indice] = ta[j];
	ta[j] = temp;
}
