#include "graphic_gui.h"

static const Cairo::RefPtr<Cairo::Context>* ptcr(nullptr); 
static double width, height;

void modifier_couleur(int r, int g, int b) {
	(*ptcr)->set_source_rgb(r, g, b);
}

void demarrer_graphic(const Cairo::RefPtr<Cairo::Context>& cr, double w, double h) {
	ptcr = &cr;
	width = w;
	height = h;
	(*ptcr)->set_line_width(EPAISSEUR);
}

void dessiner_cercle(double centre_x, double centre_y,
					 double rayon, double epaisseur) {
	(*ptcr)->set_line_width(changement_coordonnees_rayon(epaisseur));
	(*ptcr)->arc(changement_coordonnees_x(centre_x),
				 changement_coordonnees_y(centre_y),
				 changement_coordonnees_rayon(rayon), -M_PI, M_PI);
	(*ptcr)->stroke();
}

double changement_coordonnees_rayon(double rayon) {
	int facteur_echelle(2);
	return rayon*width/(facteur_echelle*dim_max);
}

double changement_coordonnees_x(double x) {
	int facteur_echelle(2);
	return width*(x + dim_max)/(facteur_echelle*dim_max);
}

double changement_coordonnees_y(double y) {
	int facteur_echelle(2);
	return height*(dim_max - y)/(facteur_echelle*dim_max);
}

void dessiner_trait(double x0, double y0, double x1, double y1, double epaisseur) {
	(*ptcr)->set_line_width(changement_coordonnees_rayon(epaisseur));
	(*ptcr)->move_to(changement_coordonnees_x(x0),
					 changement_coordonnees_y(y0));
	(*ptcr)->line_to(changement_coordonnees_x(x1),
					 changement_coordonnees_y(y1));
	(*ptcr)->stroke();
}

void errorwin(std::string& errormsg) {
	Gtk::MessageDialog dialog("ERROR");
	dialog.set_secondary_text(errormsg);
	dialog.run();
}

void rafraichir() {
	(*ptcr)->paint();
	(*ptcr)->stroke();
}
